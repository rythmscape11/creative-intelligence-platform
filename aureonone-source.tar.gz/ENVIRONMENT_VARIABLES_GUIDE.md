# Environment Variables Configuration Guide

**Date:** October 13, 2025  
**Status:** ✅ **UPDATED WITH ALL CREDENTIALS**

---

## 📋 Overview

This guide provides all environment variables needed for MediaPlanPro to function properly in development and production environments.

---

## 🔐 Required Environment Variables

### **1. Database Configuration**

```env
# PostgreSQL Database (Neon)
DATABASE_URL="postgresql://neondb_owner:npg_cZT0Cbkjv9KV@ep-fancy-dream-ad78leuw-pooler.c-2.us-east-1.aws.neon.tech/neondb?sslmode=require"
```

**Status:** ✅ Configured  
**Notes:** Production PostgreSQL database hosted on Neon

---

### **2. NextAuth.js Configuration**

```env
# NextAuth.js
NEXTAUTH_URL="http://localhost:3000"  # Development
# NEXTAUTH_URL="https://www.mediaplanpro.com"  # Production

NEXTAUTH_SECRET="mediaplanpro-secret-key-development-only"

# JWT Secret
JWT_SECRET="your-jwt-secret-here-development-only"
```

**Status:** ✅ Configured  
**Notes:** 
- Change `NEXTAUTH_URL` to production URL in Vercel
- Generate secure secrets for production using: `openssl rand -base64 32`

---

### **3. Google OAuth (Sign-in with Google)**

```env
# Google OAuth
GOOGLE_CLIENT_ID="your-google-client-id"
GOOGLE_CLIENT_SECRET="your-google-client-secret"
```

**Status:** ⚠️ **NEEDS CONFIGURATION**  
**How to Get Credentials:**

1. Go to [Google Cloud Console](https://console.cloud.google.com/apis/credentials)
2. Create a new project or select existing project
3. Enable Google+ API
4. Create OAuth 2.0 Client ID
5. Add authorized redirect URIs:
   - Development: `http://localhost:3000/api/auth/callback/google`
   - Production: `https://www.mediaplanpro.com/api/auth/callback/google`
6. Copy Client ID and Client Secret
7. Add to `.env` file (development) and Vercel (production)

**Notes:**
- Google sign-in will be disabled if credentials are not configured
- Application will still work with email/password authentication

---

### **4. Resend Email Service**

```env
# Resend Email Service
RESEND_API_KEY="re_Y3Pxb1xN_8P3SUDNRzjDAnqmkUjUKreKj"

# Optional: Custom sender email (defaults to onboarding@resend.dev)
RESEND_FROM_EMAIL="onboarding@resend.dev"
RESEND_FROM_NAME="MediaPlanPro"
RESEND_REPLY_TO_EMAIL="support@mediaplanpro.com"
```

**Status:** ✅ Configured  
**Notes:**
- Using `onboarding@resend.dev` for testing
- For production, verify your domain in Resend and use custom email

---

### **5. Stripe Payment Gateway (International)**

```env
# Stripe Payment Gateway
STRIPE_SECRET_KEY=""
STRIPE_PUBLISHABLE_KEY=""
STRIPE_WEBHOOK_SECRET=""
STRIPE_PROFESSIONAL_PRICE_ID=""
STRIPE_PROFESSIONAL_ANNUAL_PRICE_ID=""
```

**Status:** ⚠️ **NEEDS CONFIGURATION**  
**How to Get Credentials:**

1. Go to [Stripe Dashboard](https://dashboard.stripe.com)
2. Get API keys from Developers → API keys
3. Create products and prices:
   - Professional Monthly: $49/month
   - Professional Annual: $470/year
4. Set up webhook endpoint: `https://www.mediaplanpro.com/api/webhooks/stripe`
5. Copy webhook secret
6. Add all credentials to Vercel

**Notes:**
- Stripe is for international customers (USD)
- Required for payment processing

---

### **6. Razorpay Payment Gateway (India)**

```env
# Razorpay Payment Gateway
RAZORPAY_KEY_ID="rzp_live_RSvnlDEsMDR3JV"
RAZORPAY_KEY_SECRET="4lmxhYNeZza4INjSvh5dOMuT"
RAZORPAY_WEBHOOK_SECRET="B4wRFrRr4Y_HM4u"
RAZORPAY_PROFESSIONAL_PLAN_ID="plan_RSwSKydH3762TR"
RAZORPAY_PROFESSIONAL_ANNUAL_PLAN_ID="plan_RSwRRGdjIUFKHF"
```

**Status:** ✅ Configured  
**Notes:**
- Razorpay is for Indian customers (INR)
- Plans already created in Razorpay Dashboard
- Webhook configured at: `https://www.mediaplanpro.com/api/webhooks/razorpay`

---

### **7. OpenAI API (Optional)**

```env
# OpenAI API
OPENAI_API_KEY="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"
```

**Status:** ✅ Configured  
**Notes:** Used for AI-powered features (optional)

---

### **8. Analytics Configuration**

```env
# Google Analytics
NEXT_PUBLIC_GA_TRACKING_ID="G-KW67PBLSR7"
GOOGLE_ANALYTICS_ID="G-KW67PBLSR7"

# Google Tag Manager
NEXT_PUBLIC_GTM_ID="GTM-NQRV6DDM"
GOOGLE_TAG_MANAGER_ID="GTM-NQRV6DDM"

# Google Site Verification
GOOGLE_SITE_VERIFICATION="lhXZpqpqP8HCTHRmtPWXHr4YvCh_MOBIoNNFw50ouAM"

# Meta Pixel (Optional)
NEXT_PUBLIC_FB_PIXEL_ID=""
META_PIXEL_ID=""

# TikTok Pixel (Optional)
TIKTOK_PIXEL_ID=""
```

**Status:** ✅ Configured (Google Analytics and GTM)  
**Notes:** Meta and TikTok pixels are optional

---

### **9. AWS S3 (Optional)**

```env
# AWS S3
AWS_ACCESS_KEY_ID=""
AWS_SECRET_ACCESS_KEY=""
AWS_REGION="us-east-1"
AWS_S3_BUCKET="mediaplanpro-files"
```

**Status:** ⚠️ Not configured (optional)  
**Notes:** For file uploads and storage (not currently used)

---

### **10. Redis (Optional)**

```env
# Redis
REDIS_URL="redis://localhost:6379"
```

**Status:** ⚠️ Not configured (optional)  
**Notes:** For caching and session storage (not currently used)

---

### **11. Sentry (Optional)**

```env
# Sentry
SENTRY_DSN=""
SENTRY_ORG=""
SENTRY_PROJECT=""
```

**Status:** ⚠️ Not configured (optional)  
**Notes:** For error tracking and monitoring

---

### **12. SMTP Email (Optional)**

```env
# SMTP Email (Alternative to Resend)
SMTP_HOST=""
SMTP_PORT="587"
SMTP_USER=""
SMTP_PASS=""
```

**Status:** ⚠️ Not configured (using Resend instead)  
**Notes:** Alternative email service (not needed if using Resend)

---

### **13. Environment**

```env
# Environment
NODE_ENV="development"  # or "production"
```

**Status:** ✅ Configured

---

## 🚀 Vercel Deployment Configuration

### **Required for Production:**

1. **Database:**
   - ✅ `DATABASE_URL`

2. **Authentication:**
   - ✅ `NEXTAUTH_URL` (set to `https://www.mediaplanpro.com`)
   - ✅ `NEXTAUTH_SECRET` (generate new secure secret)
   - ✅ `JWT_SECRET` (generate new secure secret)
   - ⚠️ `GOOGLE_CLIENT_ID` (optional, for Google sign-in)
   - ⚠️ `GOOGLE_CLIENT_SECRET` (optional, for Google sign-in)

3. **Email:**
   - ✅ `RESEND_API_KEY`

4. **Payment Gateways:**
   - ✅ `RAZORPAY_KEY_ID`
   - ✅ `RAZORPAY_KEY_SECRET`
   - ✅ `RAZORPAY_WEBHOOK_SECRET`
   - ✅ `RAZORPAY_PROFESSIONAL_PLAN_ID`
   - ✅ `RAZORPAY_PROFESSIONAL_ANNUAL_PLAN_ID`
   - ⚠️ `STRIPE_SECRET_KEY` (optional, for international payments)
   - ⚠️ `STRIPE_PUBLISHABLE_KEY` (optional)
   - ⚠️ `STRIPE_WEBHOOK_SECRET` (optional)
   - ⚠️ `STRIPE_PROFESSIONAL_PRICE_ID` (optional)
   - ⚠️ `STRIPE_PROFESSIONAL_ANNUAL_PRICE_ID` (optional)

5. **Analytics:**
   - ✅ `NEXT_PUBLIC_GA_TRACKING_ID`
   - ✅ `NEXT_PUBLIC_GTM_ID`
   - ✅ `GOOGLE_SITE_VERIFICATION`

---

## 📝 How to Add to Vercel

1. Go to [Vercel Dashboard](https://vercel.com/dashboard)
2. Select your project (MediaPlanPro)
3. Go to **Settings** → **Environment Variables**
4. Add each variable:
   - Name: Variable name (e.g., `RAZORPAY_KEY_ID`)
   - Value: Variable value
   - Environment: Select Production, Preview, and Development as needed
5. Click **Save**
6. Redeploy the application

---

## 🔒 Security Best Practices

1. ✅ **Never commit secrets to Git**
2. ✅ **Use different secrets for development and production**
3. ✅ **Rotate secrets regularly**
4. ✅ **Use environment-specific values**
5. ✅ **Keep `.env` file in `.gitignore`**
6. ✅ **Use strong, randomly generated secrets**

---

## 🧪 Testing Configuration

To test if all environment variables are configured correctly:

1. **Check build:**
   ```bash
   npm run build
   ```

2. **Check for warnings:**
   - Look for warnings about missing API keys
   - Application should build successfully even with missing optional keys

3. **Test features:**
   - Email: Try password reset or welcome email
   - Payment: Try Razorpay checkout
   - Google Sign-in: Try signing in with Google (if configured)

---

## 📊 Configuration Status Summary

| Feature | Status | Priority |
|---------|--------|----------|
| Database | ✅ Configured | Required |
| NextAuth | ✅ Configured | Required |
| Resend Email | ✅ Configured | Required |
| Razorpay | ✅ Configured | Required |
| Google Analytics | ✅ Configured | Recommended |
| OpenAI | ✅ Configured | Optional |
| Google OAuth | ⚠️ Needs Setup | Optional |
| Stripe | ⚠️ Needs Setup | Optional |
| AWS S3 | ⚠️ Not Configured | Optional |
| Redis | ⚠️ Not Configured | Optional |
| Sentry | ⚠️ Not Configured | Optional |

---

## 🎉 Summary

**Core Features Working:**
- ✅ Database connection
- ✅ Email/password authentication
- ✅ Email notifications (Resend)
- ✅ Razorpay payments (India)
- ✅ Analytics tracking

**Optional Features:**
- ⚠️ Google OAuth (needs credentials)
- ⚠️ Stripe payments (needs credentials)
- ⚠️ File uploads (AWS S3)
- ⚠️ Error tracking (Sentry)

**Next Steps:**
1. Add Google OAuth credentials for Google sign-in
2. Add Stripe credentials for international payments
3. Test all features in production

---

**Last Updated:** October 13, 2025  
**Status:** ✅ **READY FOR PRODUCTION** (with optional features pending)

